// SINKRONISASI DATA STATE SYSTEM (LOCAL STORAGE BASED BACKEND)
const DEFAULT_STATE = {
  founder: {
    name: "Elisia Lase",
    degree: "Teknik Informatika (Informatics Engineering)",
    role: "Founder & Lead Software Engineer at Lase Web ID",
    bio: "Fokus pada arsitektur perangkat lunak modern, sistem informasi manajemen, desain antarmuka visual grafis, serta performa aplikasi web skala bisnis.",
    photo: null
  },
  logo: {
    name: "Lase Web ID",
    tagline: "SOFTWARE DEVELOPMENT AGENCY",
    image: null
  },
  contact: {
    wa: "085814496065",
    email: "lasewebid@gmail.com"
  },
  services: [
    {
      id: "srv-1",
      title: "Company Profile Website",
      desc: "Website instansi/perusahaan dengan desain grafis futuristik, animasi transisi visual interaktif, dan optimasi SEO Google Search.",
      price: 3000000,
      days: 5,
      icon: "globe"
    },
    {
      id: "srv-2",
      title: "Custom Web Application",
      desc: "Aplikasi web kustom, sistem informasi operasional manajemen bisnis, kalkulator dinamis, dan integrasi database terpisah.",
      price: 6000000,
      days: 10,
      icon: "cpu"
    },
    {
      id: "srv-3",
      title: "CMS Builder Engine",
      desc: "Sistem pembangun konten interaktif bagi klien yang ingin mengelola konten website dan landing page secara mandiri.",
      price: 8000000,
      days: 14,
      icon: "layers"
    }
  ],
  apps: [
    {
      id: "app-1",
      title: "FLP Law Firm Management System",
      version: "v2.1.0",
      desc: "Sistem Informasi Konsultasi Hukum & Pemasaran Digital berbasis Metode Scrum untuk efisiensi tim skala kecil.",
      tech: "Node.js, PostgreSQL, Tailwind CSS, Express",
      image: null,
      demoUrl: "https://laseweb.id"
    },
    {
      id: "app-2",
      title: "Lase Web Dynamic Budget Engine",
      version: "v1.4.0",
      desc: "Engine kalkulator estimasi biaya berbasis web dengan fitur tawar-menawar harga terintegrasi WhatsApp.",
      tech: "JavaScript ES6, HTML5 Canvas, LocalStorage",
      image: null,
      demoUrl: "https://laseweb.id"
    }
  ],
  reviews: [
    {
      id: "rev-1",
      name: "Advokat R. Hutagalung, S.H.",
      company: "FLP Law Firm",
      rating: 5,
      comment: "Pengerjaan sangat cepat dan rapi. Efek transisi visual grafisnya membuat company profile kantor hukum kami terlihat sangat profesional dan berkelas.",
      approved: true
    },
    {
      id: "rev-2",
      name: "Sarah Melina, M.Kom",
      company: "Tech Startup Founder",
      rating: 5,
      comment: "Fitur kalkulator harga dan sistem manajemen lead di Lase Web ID sangat membantu operasional bisnis kami. Rekomendasi banget!",
      approved: true
    },
    {
      id: "rev-3",
      name: "Dimas Prasetyo",
      company: "Digital Agency Director",
      rating: 5,
      comment: "Sangat mudah digunakan untuk mengelola konten harian. Dukungan teknis dari Founder Elisia Lase sangat responsif dan solutif.",
      approved: true
    }
  ]
};

// INITIALIZATION DATA
let appState = JSON.parse(localStorage.getItem('lase_web_state')) || DEFAULT_STATE;
let selectedServiceId = appState.services[0] ? appState.services[0].id : null;
let currentOfferPrice = 0;

function saveState() {
  localStorage.setItem('lase_web_state', JSON.stringify(appState));
  renderAllViews();
}

// DOM INITIALIZATION
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
  initCanvasParticles();
  renderAllViews();
});

// CANVAS TRANSISI VISUAL GRAFIS INTERAKTIF
function initCanvasParticles() {
  const canvas = document.getElementById('bgCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let width = canvas.width = window.innerWidth;
  let height = canvas.height = window.innerHeight;

  window.addEventListener('resize', () => {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
  });

  const particles = Array.from({ length: 45 }, () => ({
    x: Math.random() * width,
    y: Math.random() * height,
    vx: (Math.random() - 0.5) * 0.6,
    vy: (Math.random() - 0.5) * 0.6,
    radius: Math.random() * 2.5 + 1
  }));

  function animate() {
    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = 'rgba(99, 102, 241, 0.4)';
    ctx.strokeStyle = 'rgba(6, 182, 212, 0.1)';

    particles.forEach((p, i) => {
      p.x += p.vx;
      p.y += p.vy;

      if (p.x < 0 || p.x > width) p.vx *= -1;
      if (p.y < 0 || p.y > height) p.vy *= -1;

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      ctx.fill();

      for (let j = i + 1; j < particles.length; j++) {
        const p2 = particles[j];
        const dist = Math.hypot(p.x - p2.x, p.y - p2.y);
        if (dist < 120) {
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.stroke();
        }
      }
    });

    requestAnimationFrame(animate);
  }
  animate();
}

// TAB NAVIGATION SWITCHER
function switchTab(tabId) {
  document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
  const activeTab = document.getElementById(`tab-${tabId}`);
  if (activeTab) {
    activeTab.classList.remove('hidden');
  }

  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.classList.remove('active', 'bg-indigo-600', 'text-white');
    btn.classList.add('text-slate-300');
  });

  event?.target?.classList?.add('active', 'bg-indigo-600', 'text-white');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// RENDER PUBLIC FRONTEND & ADMIN DASHBOARD VIEWS
function renderAllViews() {
  renderBrandingAndFounder();
  renderServices();
  renderAppReleases();
  renderReviews();
  renderCalculator();
  renderAdminPanelContent();
  lucide.createIcons();
}

function renderBrandingAndFounder() {
  const { logo, founder, contact } = appState;

  // Logo Brand Nav & Hero
  document.getElementById('nav-brand-name').textContent = logo.name;
  document.getElementById('nav-brand-tagline').textContent = logo.tagline;
  document.getElementById('hero-brand-name').textContent = logo.name;
  document.getElementById('footer-brand-name').textContent = logo.name;
  document.getElementById('footer-founder-name').textContent = founder.name;
  document.getElementById('footer-wa-val').textContent = contact.wa;
  document.getElementById('footer-email-val').textContent = contact.email;
  document.getElementById('contact-email-val').textContent = contact.email;
  document.getElementById('contact-wa-val').textContent = contact.wa;

  // Custom Logo Image If Exists
  const logoContainer = document.getElementById('nav-logo-container');
  if (logo.image) {
    logoContainer.innerHTML = `<img src="${logo.image}" class="w-full h-full object-cover rounded-[10px]" />`;
  } else {
    logoContainer.innerHTML = `<div class="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center"><i data-lucide="code-2" class="w-5 h-5 text-cyan-400"></i></div>`;
  }

  // Founder Profile Cards
  const founderHTML = `
    <div class="flex flex-col md:flex-row items-center gap-8">
      <div class="w-32 h-32 rounded-3xl bg-gradient-to-tr from-indigo-600 to-cyan-400 p-1 shrink-0 shadow-xl shadow-indigo-500/20 overflow-hidden">
        ${founder.photo ? `<img src="${founder.photo}" class="w-full h-full object-cover rounded-[22px]" />` : `
          <div class="w-full h-full bg-slate-950 rounded-[22px] flex flex-col items-center justify-center text-center p-3">
            <i data-lucide="user-check" class="w-10 h-10 text-cyan-400 mb-1"></i>
            <span class="text-xs font-bold text-white uppercase">${founder.name}</span>
            <span class="text-[9px] text-indigo-300 font-mono">FOUNDER</span>
          </div>
        `}
      </div>
      <div class="space-y-3 text-center md:text-left">
        <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-mono">
          <i data-lucide="graduation-cap" class="w-3.5 h-3.5 text-cyan-400"></i>
          <span>${founder.degree}</span>
        </div>
        <h2 class="text-3xl font-extrabold text-white">${founder.name}</h2>
        <p class="text-xs text-cyan-400 font-mono">${founder.role}</p>
        <p class="text-slate-300 text-sm leading-relaxed">${founder.bio}</p>
      </div>
    </div>
  `;

  document.getElementById('home-founder-card').innerHTML = founderHTML;
  document.getElementById('founder-full-page').innerHTML = founderHTML;
}

function renderServices() {
  const gridHTML = appState.services.map(s => `
    <div class="glass-card p-8 rounded-3xl space-y-4 hover:border-indigo-500/50 transition-all">
      <div class="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
        <i data-lucide="${s.icon || 'code'}" class="w-6 h-6"></i>
      </div>
      <h3 class="text-xl font-bold text-white">${s.title}</h3>
      <p class="text-slate-300 text-xs leading-relaxed">${s.desc}</p>
      <div class="pt-2 flex items-center justify-between text-xs font-mono text-cyan-300">
        <span>Rp ${s.price.toLocaleString('id-ID')}</span>
        <span>~${s.days} Hari Kerja</span>
      </div>
    </div>
  `).join('');

  document.getElementById('home-services-grid').innerHTML = gridHTML;
  document.getElementById('services-page-grid').innerHTML = gridHTML;
}

function renderAppReleases() {
  const appsHTML = appState.apps.map(a => `
    <div class="glass-card p-6 rounded-3xl space-y-4 border-indigo-500/30">
      ${a.image ? `<img src="${a.image}" class="w-full h-40 object-cover rounded-2xl border border-slate-800" />` : ''}
      <div class="flex items-center justify-between">
        <span class="bg-indigo-500/20 text-indigo-300 text-xs font-mono px-3 py-1 rounded-full border border-indigo-500/30">${a.version}</span>
        ${a.demoUrl ? `<a href="${a.demoUrl}" target="_blank" class="text-xs text-cyan-400 font-mono flex items-center gap-1 hover:underline"><i data-lucide="external-link" class="w-3.5 h-3.5"></i> Live Demo</a>` : ''}
      </div>
      <h4 class="text-xl font-bold text-white">${a.title}</h4>
      <p class="text-slate-300 text-xs leading-relaxed">${a.desc}</p>
      <div class="text-[11px] font-mono text-slate-400">Tech: ${a.tech}</div>
    </div>
  `).join('');

  document.getElementById('home-apps-grid').innerHTML = appsHTML;
  document.getElementById('apps-page-grid').innerHTML = appsHTML;
}

function renderReviews() {
  const approved = appState.reviews.filter(r => r.approved);
  const reviewsHTML = approved.map(r => `
    <div class="glass-card p-6 rounded-3xl space-y-4 flex flex-col justify-between">
      <div class="space-y-3">
        <div class="flex items-center justify-between">
          <span class="text-xs font-bold text-cyan-300 font-mono">${r.company}</span>
          <div class="flex text-amber-400">${'★'.repeat(r.rating)}</div>
        </div>
        <p class="text-slate-300 text-xs italic leading-relaxed">"${r.comment}"</p>
      </div>
      <div class="pt-4 border-t border-slate-800 flex items-center justify-between text-xs">
        <span class="font-bold text-white">${r.name}</span>
        <span class="text-slate-400 font-mono">Klien Terverifikasi</span>
      </div>
    </div>
  `).join('');

  document.getElementById('home-reviews-grid').innerHTML = reviewsHTML;
  document.getElementById('reviews-page-grid').innerHTML = reviewsHTML;
}

function renderCalculator() {
  const buttonsHTML = appState.services.map(s => `
    <button onclick="selectCalcService('${s.id}')" class="calc-type-btn glass-card p-4 rounded-xl text-left border ${selectedServiceId === s.id ? 'border-indigo-500 bg-indigo-600/20' : 'border-slate-800'}">
      <span class="block text-sm font-bold text-white">${s.title}</span>
      <span class="text-[11px] text-slate-400">Rp ${s.price.toLocaleString('id-ID')}</span>
    </button>
  `).join('');

  document.getElementById('calc-service-buttons').innerHTML = buttonsHTML;
  recalculateTotal();
}

function selectCalcService(id) {
  selectedServiceId = id;
  renderCalculator();
}

function updatePages(val) {
  document.getElementById('calc-pages-val').textContent = `${val} Halaman`;
  recalculateTotal();
}

function calculateOffer() {
  const val = parseFloat(document.getElementById('offer-price-input').value) || 0;
  currentOfferPrice = val;
  recalculateTotal();
}

function recalculateTotal() {
  const service = appState.services.find(s => s.id === selectedServiceId) || appState.services[0];
  if (!service) return;

  const pages = parseInt(document.getElementById('calc-pages-input').value) || 1;
  const baseTotal = service.price + ((pages - 1) * 200000);
  const estDays = service.days + Math.floor(pages / 3);

  document.getElementById('calc-result-price').textContent = `Rp ${baseTotal.toLocaleString('id-ID')}`;
  document.getElementById('calc-result-days').textContent = `Estimasi Pengerjaan: ~${estDays} Hari Kerja`;

  const offerDisplay = document.getElementById('offer-result-display');
  const offerStatus = document.getElementById('offer-status-text');

  if (currentOfferPrice > 0) {
    offerDisplay.classList.remove('hidden');
    offerDisplay.textContent = `Ajuan Tawar: Rp ${currentOfferPrice.toLocaleString('id-ID')}`;
    if (currentOfferPrice < baseTotal * 0.7) {
      offerStatus.textContent = '* Tawaran Anda cukup rendah, silakan diskusikan lebih lanjut dengan admin.';
      offerStatus.className = 'text-xs text-amber-400 font-mono';
    } else {
      offerStatus.textContent = '* Nominal tawaran rasional dan siap diproses.';
      offerStatus.className = 'text-xs text-emerald-400 font-mono';
    }
  } else {
    offerDisplay.classList.add('hidden');
    offerStatus.textContent = '';
  }
}

function sendToWhatsappOffer() {
  const service = appState.services.find(s => s.id === selectedServiceId) || appState.services[0];
  const pages = document.getElementById('calc-pages-input').value;
  const baseTotal = service.price + ((pages - 1) * 200000);
  const offerText = currentOfferPrice > 0 ? `Rp ${currentOfferPrice.toLocaleString('id-ID')}` : 'Mengikuti Estimasi Standar Sistem';

  const text = `Halo Founder Elisia Lase (Lase Web ID), saya ingin memesan layanan:%0A- Layanan: ${service.title}%0A- Modul/Halaman: ${pages}%0A- Estimasi Sistem: Rp ${baseTotal.toLocaleString('id-ID')}%0A- Ajuan Tawar Budget: ${offerText}%0A%0AMohon konfirmasi kelanjutan proyek ini. Terima kasih!`;
  window.open(`https://wa.me/62${appState.contact.wa}?text=${text}`, '_blank');
}

function sendGeneralContactToWA() {
  const text = `Halo Founder Elisia Lase (Lase Web ID), saya ingin berkonsultasi mengenai pembuatan sistem informasi / web application.`;
  window.open(`https://wa.me/62${appState.contact.wa}?text=${text}`, '_blank');
}

function submitPublicReview(e) {
  e.preventDefault();
  const name = document.getElementById('public-rev-name').value;
  const company = document.getElementById('public-rev-company').value;
  const rating = parseInt(document.getElementById('public-rev-rating').value);
  const comment = document.getElementById('public-rev-comment').value;

  appState.reviews.push({
    id: `rev-${Date.now()}`,
    name,
    company,
    rating,
    comment,
    approved: false
  });

  saveState();
  alert('Testimoni Anda berhasil dikirim dan akan diverifikasi oleh Admin Dashboard!');
  e.target.reset();
}

// ADMIN DASHBOARD CONTROLLERS
function openAdminModal() {
  document.getElementById('admin-modal').classList.remove('hidden');
}

function closeAdminModal() {
  document.getElementById('admin-modal').classList.add('hidden');
}

function handleAdminLogin(e) {
  e.preventDefault();
  const email = document.getElementById('login-email').value;
  const pass = document.getElementById('login-password').value;

  if (email === 'lasewebid@gmail.com' && pass === 'Lasewebid123456789') {
    document.getElementById('admin-login-view').classList.add('hidden');
    document.getElementById('admin-panel-view').classList.remove('hidden');
    renderAdminPanelContent();
  } else {
    const err = document.getElementById('login-error-msg');
    err.textContent = 'Email atau Password Admin Salah!';
    err.classList.remove('hidden');
  }
}

function handleAdminLogout() {
  document.getElementById('admin-login-view').classList.remove('hidden');
  document.getElementById('admin-panel-view').classList.add('hidden');
}

function switchAdminSubTab(subId) {
  document.querySelectorAll('.adm-sub-content').forEach(el => el.classList.add('hidden'));
  document.querySelectorAll('.adm-subtab-btn').forEach(btn => {
    btn.classList.remove('active', 'bg-indigo-600', 'text-white');
    btn.classList.add('text-slate-400');
  });

  document.getElementById(`adm-sub-${subId}`).classList.remove('hidden');
  document.getElementById(`adm-tab-${subId}`).classList.add('active', 'bg-indigo-600', 'text-white');
}

function handleImageUpload(event, previewId) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(e) {
    const previewImg = document.getElementById(previewId);
    previewImg.src = e.target.result;
    previewImg.classList.remove('hidden');
    previewImg.dataset.base64 = e.target.result;
  };
  reader.readAsDataURL(file);
}

function renderAdminPanelContent() {
  // Founder Settings Fill
  document.getElementById('adm-founder-name').value = appState.founder.name;
  document.getElementById('adm-founder-degree').value = appState.founder.degree;
  document.getElementById('adm-founder-role').value = appState.founder.role;
  document.getElementById('adm-founder-bio').value = appState.founder.bio;

  // Logo Fill
  document.getElementById('adm-logo-name').value = appState.logo.name;
  document.getElementById('adm-logo-tagline').value = appState.logo.tagline;

  // Contact Fill
  document.getElementById('adm-contact-wa').value = appState.contact.wa;
  document.getElementById('adm-contact-email').value = appState.contact.email;

  // Services Admin List
  document.getElementById('adm-services-list').innerHTML = appState.services.map(s => `
    <div class="glass-card p-4 rounded-xl flex items-center justify-between gap-4">
      <div>
        <h5 class="font-bold text-white text-sm">${s.title}</h5>
        <p class="text-xs text-slate-400">Rp ${s.price.toLocaleString('id-ID')} | ~${s.days} Hari</p>
      </div>
      <button onclick="deleteService('${s.id}')" class="text-xs text-rose-400 font-mono hover:underline">Hapus</button>
    </div>
  `).join('');

  // Apps Admin List
  document.getElementById('adm-apps-list').innerHTML = appState.apps.map(a => `
    <div class="glass-card p-4 rounded-xl flex items-center justify-between gap-4">
      <div>
        <h5 class="font-bold text-white text-sm">${a.title} (${a.version})</h5>
        <p class="text-xs text-slate-400">${a.desc}</p>
      </div>
      <button onclick="deleteApp('${a.id}')" class="text-xs text-rose-400 font-mono hover:underline">Hapus</button>
    </div>
  `).join('');

  // Reviews Admin List
  document.getElementById('adm-reviews-list').innerHTML = appState.reviews.map(r => `
    <div class="glass-card p-4 rounded-xl flex items-center justify-between gap-4">
      <div>
        <h5 class="font-bold text-white text-sm">${r.name} (${r.company}) - ${'★'.repeat(r.rating)}</h5>
        <p class="text-xs text-slate-300 italic">"${r.comment}"</p>
        <span class="text-[10px] font-mono ${r.approved ? 'text-emerald-400' : 'text-amber-400'}">${r.approved ? 'Terpublish' : 'Menunggu Moderasi'}</span>
      </div>
      <div class="flex items-center gap-2">
        <button onclick="toggleApproveReview('${r.id}')" class="text-xs ${r.approved ? 'text-amber-400' : 'text-emerald-400'} font-mono hover:underline">${r.approved ? 'Unpublish' : 'Publish'}</button>
        <button onclick="deleteReview('${r.id}')" class="text-xs text-rose-400 font-mono hover:underline">Hapus</button>
      </div>
    </div>
  `).join('');
}

function saveFounderSettings(e) {
  e.preventDefault();
  appState.founder.name = document.getElementById('adm-founder-name').value;
  appState.founder.degree = document.getElementById('adm-founder-degree').value;
  appState.founder.role = document.getElementById('adm-founder-role').value;
  appState.founder.bio = document.getElementById('adm-founder-bio').value;

  const imgPrev = document.getElementById('adm-founder-photo-preview');
  if (imgPrev.dataset.base64) {
    appState.founder.photo = imgPrev.dataset.base64;
  }

  saveState();
  alert('Profil Founder berhasil disimpan!');
}

function saveLogoSettings(e) {
  e.preventDefault();
  appState.logo.name = document.getElementById('adm-logo-name').value;
  appState.logo.tagline = document.getElementById('adm-logo-tagline').value;

  const imgPrev = document.getElementById('adm-logo-preview');
  if (imgPrev.dataset.base64) {
    appState.logo.image = imgPrev.dataset.base64;
  }

  saveState();
  alert('Logo & Branding berhasil diperbarui!');
}

function saveContactSettings(e) {
  e.preventDefault();
  appState.contact.wa = document.getElementById('adm-contact-wa').value;
  appState.contact.email = document.getElementById('adm-contact-email').value;

  saveState();
  alert('Kontak agensi berhasil disimpan!');
}

function openAppFormModal() {
  document.getElementById('app-form-modal').classList.remove('hidden');
}

function closeAppFormModal() {
  document.getElementById('app-form-modal').classList.add('hidden');
}

function saveAppRelease(e) {
  e.preventDefault();
  const imgPrev = document.getElementById('app-form-preview');

  appState.apps.push({
    id: `app-${Date.now()}`,
    title: document.getElementById('app-form-title').value,
    version: document.getElementById('app-form-version').value,
    desc: document.getElementById('app-form-desc').value,
    tech: document.getElementById('app-form-tech').value,
    demoUrl: document.getElementById('app-form-url').value,
    image: imgPrev.dataset.base64 || null
  });

  saveState();
  closeAppFormModal();
  alert('Aplikasi baru berhasil dirilis di Frontend!');
}

function deleteService(id) {
  appState.services = appState.services.filter(s => s.id !== id);
  saveState();
}

function deleteApp(id) {
  appState.apps = appState.apps.filter(a => a.id !== id);
  saveState();
}

function toggleApproveReview(id) {
  const rev = appState.reviews.find(r => r.id === id);
  if (rev) {
    rev.approved = !rev.approved;
    saveState();
  }
}

function deleteReview(id) {
  appState.reviews = appState.reviews.filter(r => r.id !== id);
  saveState();
}
